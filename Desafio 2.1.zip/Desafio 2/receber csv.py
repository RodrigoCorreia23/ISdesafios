import csv
import os
import lxml.etree as etree
from tkinter import Tk, filedialog

# Selecionar ficheiro CSV
def selecionar_ficheiro_csv():
    root = Tk()
    root.withdraw()
    ficheiro_csv = filedialog.askopenfilename(
        title="Selecione o ficheiro CSV",
        filetypes=[("CSV files", "*.csv")]
    )
    root.destroy()
    return ficheiro_csv

# Converter CSV para XML
def csv_para_xml(ficheiro_csv, nome_xml):
    root = etree.Element("root")
    
    with open(ficheiro_csv, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        
        for row in reader:
            item = etree.SubElement(root, "item")
            for key, value in row.items():
                child = etree.SubElement(item, key)
                child.text = value
    
    tree = etree.ElementTree(root)
    tree.write(nome_xml, encoding="utf-8", xml_declaration=True, pretty_print=True)

# Gerar XSD simples a partir do XML
def gerar_xsd_simples(nome_xml, nome_xsd):
    tree = etree.parse(nome_xml)
    root = tree.getroot()

    XS_NAMESPACE = "http://www.w3.org/2001/XMLSchema"
    schema_root = etree.Element("{%s}schema" % XS_NAMESPACE, 
                                nsmap={'xs': XS_NAMESPACE}, 
                                elementFormDefault="qualified")

    element_root = etree.SubElement(schema_root, "{%s}element" % XS_NAMESPACE, name="root")
    complex_type_root = etree.SubElement(element_root, "{%s}complexType" % XS_NAMESPACE)
    sequence_root = etree.SubElement(complex_type_root, "{%s}sequence" % XS_NAMESPACE)

    element_item = etree.SubElement(sequence_root, "{%s}element" % XS_NAMESPACE, name="item", maxOccurs="unbounded")
    complex_type_item = etree.SubElement(element_item, "{%s}complexType" % XS_NAMESPACE)
    sequence_item = etree.SubElement(complex_type_item, "{%s}sequence" % XS_NAMESPACE)

    first_item = root.find("item")
    if first_item is not None:
        for child in first_item:
            etree.SubElement(sequence_item, "{%s}element" % XS_NAMESPACE, name=child.tag, type="xs:string")

    xsd_tree = etree.ElementTree(schema_root)
    xsd_tree.write(nome_xsd, encoding="utf-8", xml_declaration=True, pretty_print=True)

# Validar XML com o XSD
def validar_xml(nome_xml, nome_xsd):
    try:
        xmlschema_doc = etree.parse(nome_xsd)
        xmlschema = etree.XMLSchema(xmlschema_doc)
        
        xml_doc = etree.parse(nome_xml)
        is_valid = xmlschema.validate(xml_doc)
        
        if not is_valid:
            for error in xmlschema.error_log:
                print(f"Erro de validação: {error.message} na linha {error.line}.")
        return is_valid
    except etree.XMLSchemaParseError as e:
        print(f"Erro ao carregar o XSD: {e}")
        return False
    except etree.XMLSyntaxError as e:
        print(f"Erro de sintaxe no XML: {e}")
        return False
    except Exception as e:
        print(f"Ocorreu um erro durante a validação: {e}")
        return False

# Criar Sub-XML filtrado por categoria
def criar_sub_xml(nome_xml, nome_sub_xml, tag, valor):
    tree = etree.parse(nome_xml)
    root = tree.getroot()
    
    sub_root = etree.Element("root")
    
    for item in root.findall("item"):
        if item.find(tag) is not None and item.find(tag).text == valor:
            sub_root.append(item)
    
    sub_tree = etree.ElementTree(sub_root)
    sub_tree.write(nome_sub_xml, encoding="utf-8", xml_declaration=True, pretty_print=True)

# Explorar Sub-XML com XPath
def explorar_com_xpath(nome_xml, xpath_expr):
    tree = etree.parse(nome_xml)
    results = tree.xpath(xpath_expr)
    return results

# Explorar Sub-XML com XQuery-like search and process <a> tags
def explorar_com_xquery(nome_xml, xquery_expr):
    tree = etree.parse(nome_xml)
    results = tree.xpath(xquery_expr)

    # Process results and specifically handle <a> tags for 'href' and 'name' attributes
    for element in results:
        if element.tag == "a":
            attributes = element.attrib
            if "href" in attributes:
                print(f"'{element.text}' está no URL '{attributes['href']}'.")
            if "name" in attributes:
                print(f"'{element.text}' ancorado em '{attributes['name']}'.")

    return results

def main():
    # Selecionar ficheiro CSV
    ficheiro_csv = selecionar_ficheiro_csv()
    if not ficheiro_csv:
        print("Nenhum ficheiro CSV foi selecionado.")
        return

    # Converter CSV para XML
    nome_xml = os.path.splitext(ficheiro_csv)[0] + ".xml"
    csv_para_xml(ficheiro_csv, nome_xml)
    print(f"ficheiro XML '{nome_xml}' gerado a partir do CSV.")

    # Gerar XSD a partir do XML gerado
    nome_xsd = "schema.xsd"
    gerar_xsd_simples(nome_xml, nome_xsd)
    print(f"ficheiro XSD '{nome_xsd}' gerado com base no XML.")

    # Validar XML com XSD gerado
    if validar_xml(nome_xml, nome_xsd):
        print("O XML é válido segundo o XSD gerado.")
    else:
        print("O XML NÃO é válido segundo o XSD gerado.")
        return

    # Definir nome para o Sub-XML
    nome_sub_xml = "SUB-" + os.path.splitext(os.path.basename(ficheiro_csv))[0] + ".xml"

    # Criar Sub-XML filtrado por categoria
    tag_categoria = input("Insira o nome da categoria para filtragem (ex.: gender): ")
    valor_categoria = input("Insira um valor existente na categoria para filtragem (ex.: 1): ")
    criar_sub_xml(nome_xml, nome_sub_xml, tag_categoria, valor_categoria)
    print(f"Sub-XML '{nome_sub_xml}' criado com base na categoria.")

    # Explorar Sub-XML com XPath
    xpath_expr = input("Insira a expressão XPath para explorar o Sub-XML: ")
    resultados_xpath = explorar_com_xpath(nome_sub_xml, xpath_expr)

    # Exibe os resultados da consulta ou uma mensagem informando que está vazio
    if resultados_xpath:
        print("Resultados da consulta XPath:")
        for r in resultados_xpath:
            print(etree.tostring(r, encoding="utf-8").decode("utf-8"))
    else:
        print("A consulta XPath não retornou resultados. Verifique a expressão e a estrutura do Sub-XML.")
    
    # Explorar Sub-XML com XQuery-like expression and <a> tag processing
    xquery_expr = input("Insira a expressão XQuery para explorar o Sub-XML (para procurar tags <a>): ")
    resultados_xquery = explorar_com_xquery(nome_sub_xml, xquery_expr)

    # Exibe os resultados da consulta XQuery ou uma mensagem informando que está vazio
    if resultados_xquery:
        print("Resultados da consulta XQuery:")
        for r in resultados_xquery:
            print(etree.tostring(r, encoding="utf-8").decode("utf-8"))
    else:
        print("A consulta XQuery não retornou resultados. Verifique a expressão e a estrutura do Sub-XML.")

if __name__ == "__main__":
    main()
